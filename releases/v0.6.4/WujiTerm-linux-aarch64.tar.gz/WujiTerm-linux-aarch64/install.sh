#!/usr/bin/env bash
set -euo pipefail

PREFIX="${PREFIX:-${HOME}/.local}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "${PREFIX}/bin" "${PREFIX}/share/applications" "${PREFIX}/share/icons/hicolor/1024x1024/apps"
install -m 755 "${SCRIPT_DIR}/bin/wujiterm" "${PREFIX}/bin/wujiterm"
install -m 755 "${SCRIPT_DIR}/bin/wuji" "${PREFIX}/bin/wuji"
install -m 755 "${SCRIPT_DIR}/bin/wuji-sync-server" "${PREFIX}/bin/wuji-sync-server"

if [[ -f "${SCRIPT_DIR}/share/applications/wujiterm.desktop" ]]; then
  sed "s|^Exec=.*|Exec=${PREFIX}/bin/wujiterm %F|" \
    "${SCRIPT_DIR}/share/applications/wujiterm.desktop" \
    > "${PREFIX}/share/applications/wujiterm.desktop"
fi
if [[ -f "${SCRIPT_DIR}/share/icons/hicolor/1024x1024/apps/wujiterm.png" ]]; then
  install -m 644 "${SCRIPT_DIR}/share/icons/hicolor/1024x1024/apps/wujiterm.png" \
    "${PREFIX}/share/icons/hicolor/1024x1024/apps/wujiterm.png"
fi

if command -v update-desktop-database >/dev/null 2>&1; then
  update-desktop-database "${PREFIX}/share/applications" >/dev/null 2>&1 || true
fi

echo "Installed WujiTerm to ${PREFIX}/bin/{wujiterm,wuji,wuji-sync-server}"
