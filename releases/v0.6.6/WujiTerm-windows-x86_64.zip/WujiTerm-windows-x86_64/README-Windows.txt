WujiTerm for Windows 10 / Windows 11 (x86_64)
=============================================

1. 解压本压缩包到任意固定目录（如 D:\Apps\WujiTerm），直接双击 wujiterm.exe 即可运行（免安装绿色单文件版，无需管理员权限）。
2. 安全软件误报说明：
   - 本软件为 Rust + libghostty-vt 原生编译的 SSH / 堡垒机 / 数据库终端工具，当前内测版尚未附加商业 EV/OV 代码签名证书。
   - 若通过微信接收时被 360 安全卫士 / 电脑管家「木马云查杀」误拦截，属于国产杀软对「无商业数字签名的新编译终端程序」的常见启发式误报；可在杀毒软件「恢复区 / 信任区」恢复文件并将本解压目录加入信任白名单。
   - 若首次双击弹出 Windows SmartScreen 蓝色提示，点击「更多信息」->「仍要运行」即可。
3. 配置文件自动生成于：%USERPROFILE%\.config\wujiterm\config.toml（与 macOS 版格式 100% 通用；旧版 .config\coolwj 配置将在首次启动时自动无损迁移）。
4. SSH 密码与密钥口令默认通过 Windows 系统「凭据管理器」DPAPI 加密保护，也可在「设置 -> 密钥与保险库」切换为独立主密码本地加密保险库（vault.enc）。
5. 常用快捷键：
   - Ctrl + Shift + P      打开全局命令面板
   - Ctrl + Shift + T      新建本地 PowerShell 终端标签页
   - Ctrl + Shift + D / E  左右分屏 / 上下分屏
   - Alt + Z               切换超长日志「单行横向滚动」与「自动折行」
   - Ctrl + Shift + L      实时日志过滤抽屉 / TraceId 专注视图
   - Alt + Shift + F       一键格式化（JSON / SQL / Java堆栈 / Cron）
   - Alt + Shift + C       一键脱敏复制
   - Alt + I               AI 运维副驾驶
